﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Worker
    {
        [Key]
        public Guid ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public ICollection<Proffession> Proffession_ID { get; set; }
        public ICollection<SickNote> SickNote_ID { get; set; }
        public ICollection<Rent> Rent_ID { get; set; }
        public ICollection<Child> Children_ID { get; set; }
        public ICollection<Vacation> Vacations_ID { get; set; }
    }
}
