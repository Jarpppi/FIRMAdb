﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }
        public DbSet<Proffession> WorkerProffessions { get; set; }
        public DbSet<SickNote> sickDays { get; set; }
        public DbSet<Rent> Rentings { get; set; }
        public DbSet<Child> children { get; set; }
        public DbSet<Vacation> vacations { get; set; }
        public DbSet<Worker> workers { get; set; }
    }
}